package com.hcl.management;

public class ApiStatusCode {
   
	public static final int PORTFOLIO_NOT_FOUND=401;
	
	public static final int INVALID_DATA=600;
	
}
